@extends('layouts.app')

@section('content')
<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-4">Clinic Dashboard</h1>
    <p>Welcome Clinic! Manage appointments, billing, and patient cases here.</p>
</div>
@endsection
