@extends('layouts.app')

@section('content')
<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-4">Admin Dashboard</h1>
    <p>Welcome Admin! Manage users, reports, and system settings here.</p>
</div>
@endsection
