<?php $__env->startSection('content'); ?>
<div class="p-6 bg-gray-300 min-h-screen">
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Admin Dashboard</h1>

    <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-gray-500 text-sm font-medium">Clinics</h3>
            <p class="text-3xl font-bold text-blue-600 mt-2"><?php echo e($totalClinics); ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-gray-500 text-sm font-medium">Case Orders</h3>
            <p class="text-3xl font-bold text-green-600 mt-2"><?php echo e($totalCaseOrders); ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-gray-500 text-sm font-medium">Appointments</h3>
            <p class="text-3xl font-bold text-purple-600 mt-2"><?php echo e($totalAppointments); ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-gray-500 text-sm font-medium">Technicians</h3>
            <p class="text-3xl font-bold text-orange-600 mt-2"><?php echo e($totalTechnicians); ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-gray-500 text-sm font-medium">Riders</h3>
            <p class="text-3xl font-bold text-red-600 mt-2"><?php echo e($totalRiders); ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-gray-500 text-sm font-medium">Materials</h3>
            <p class="text-3xl font-bold text-teal-600 mt-2"><?php echo e($totalMaterials); ?></p>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Appointments -->
        <div class="bg-white rounded-lg shadow p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Recent Appointments</h2>
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $recentAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="border-l-4 border-blue-500 pl-4 py-2">
                    <p class="font-semibold"><?php echo e($appointment->caseOrder->clinic->clinic_name ?? 'N/A'); ?></p>
                    <p class="text-sm text-gray-600"><?php echo e($appointment->schedule_datetime->format('M d, Y h:i A')); ?></p>
                    <div class="text-xs w-fit px-2 py-1 bg-blue-100 text-blue-800 rounded"><?php echo e($appointment->work_status); ?></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500">No appointments yet.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Pending Case Orders -->
        <div class="bg-white rounded-lg shadow p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Pending Case Orders</h2>
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $pendingCaseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="border-l-4 border-yellow-500 pl-4 py-2">
                    <p class="font-semibold"><?php echo e($order->clinic->clinic_name ?? 'N/A'); ?></p>
                    <p class="text-sm text-gray-600">Patient: <?php echo e($order->patient->name ?? 'N/A'); ?></p>
                    <p class="text-xs text-gray-500"><?php echo e($order->case_type); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500">No pending orders.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ᴄᴛOS\Desktop\CAPSTONE\denture-lab-system\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>