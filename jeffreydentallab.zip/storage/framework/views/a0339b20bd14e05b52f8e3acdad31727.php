<?php $__env->startSection('page-title', 'Create Appointment'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 bg-gray-100 min-h-screen">
    <div class="max-w-4xl mx-auto">

        <a href="<?php echo e(route('admin.appointments.index')); ?>" class="text-blue-600 hover:underline mb-4 inline-block">
            ← Back to Appointments
        </a>

        <div class="bg-white rounded-lg shadow-lg p-6">
            <h1 class="text-2xl font-bold text-gray-800 mb-6">Create New Appointment</h1>

            <?php if($errors->any()): ?>
            <div class="mb-4 p-4 bg-red-100 border border-red-300 text-red-700 rounded">
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <form action="<?php echo e(route('admin.appointments.store')); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>

                <!-- Case Order Selection -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Case Order <span class="text-red-500">*</span>
                    </label>

                    <?php if($caseOrder): ?>
                    <!-- Pre-selected case order -->
                    <div class="border-2 border-blue-500 rounded-lg p-4 bg-blue-50">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="font-semibold text-gray-800">CASE-<?php echo e(str_pad($caseOrder->co_id, 5, '0',
                                    STR_PAD_LEFT)); ?></p>
                                <p class="text-sm text-gray-600">Clinic: <?php echo e($caseOrder->clinic->clinic_name); ?></p>
                                <p class="text-sm text-gray-600">Patient: <?php echo e($caseOrder->patient->name); ?></p>
                                <p class="text-sm text-gray-600">Type: <?php echo e($caseOrder->case_type); ?></p>
                            </div>
                            <span class="px-3 py-1 bg-blue-600 text-white rounded-full text-xs">Selected</span>
                        </div>
                    </div>
                    <input type="hidden" name="case_order_id" value="<?php echo e($caseOrder->co_id); ?>">
                    <?php else: ?>
                    <!-- Dropdown selection -->
                    <select name="case_order_id" id="caseOrderSelect" required
                        class="w-full border-2 border-gray-300 rounded-lg p-3 focus:border-blue-500 focus:outline-none">
                        <option value="">-- Select Case Order --</option>
                        <?php $__currentLoopData = $caseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($order->co_id); ?>" data-clinic="<?php echo e($order->clinic->clinic_name); ?>"
                            data-patient="<?php echo e($order->patient->name); ?>" data-type="<?php echo e($order->case_type); ?>">
                            CASE-<?php echo e(str_pad($order->co_id, 5, '0', STR_PAD_LEFT)); ?> - <?php echo e($order->clinic->clinic_name); ?>

                            - <?php echo e($order->patient->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <!-- Case Order Details Preview -->
                    <div id="caseOrderPreview" class="hidden mt-3 p-4 bg-gray-50 rounded-lg border">
                        <p class="text-sm text-gray-600"><strong>Clinic:</strong> <span id="previewClinic"></span></p>
                        <p class="text-sm text-gray-600"><strong>Patient:</strong> <span id="previewPatient"></span></p>
                        <p class="text-sm text-gray-600"><strong>Case Type:</strong> <span id="previewType"></span></p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Technician Selection -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Assign Technician <span class="text-red-500">*</span>
                    </label>
                    <select name="technician_id" required
                        class="w-full border-2 border-gray-300 rounded-lg p-3 focus:border-blue-500 focus:outline-none">
                        <option value="">-- Select Technician --</option>
                        <?php $__currentLoopData = $technicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technician): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($technician->id); ?>">
                            <?php echo e($technician->name); ?> - <?php echo e($technician->email); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <p class="text-xs text-gray-500 mt-1">The technician will be notified immediately upon appointment
                        creation.</p>
                </div>

                <!-- Schedule Date & Time -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Schedule Date & Time <span class="text-red-500">*</span>
                    </label>
                    <input type="datetime-local" name="schedule_datetime" min="<?php echo e(date('Y-m-d\TH:i')); ?>" required
                        class="w-full border-2 border-gray-300 rounded-lg p-3 focus:border-blue-500 focus:outline-none">
                    <p class="text-xs text-gray-500 mt-1">Select the date and time for this appointment</p>
                </div>


                <!-- Purpose/Notes -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Purpose / Work Description
                    </label>
                    <textarea name="purpose" rows="4"
                        class="w-full border-2 border-gray-300 rounded-lg p-3 focus:border-blue-500 focus:outline-none"
                        placeholder="Describe the work to be done, any special instructions, etc."></textarea>
                </div>

                <!-- Info Box -->
                

                <!-- Action Buttons -->
                <div class="flex justify-end gap-3 pt-4 border-t">
                    <a href="<?php echo e(route('admin.appointments.index')); ?>"
                        class="px-6 py-3 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition">
                        Cancel
                    </a>
                    <button type="submit"
                        class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-semibold">
                        Create Appointment
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Case order preview (if not pre-selected)
const caseOrderSelect = document.getElementById('caseOrderSelect');
if (caseOrderSelect) {
    caseOrderSelect.addEventListener('change', function() {
        const selected = this.options[this.selectedIndex];
        if (this.value) {
            document.getElementById('previewClinic').textContent = selected.dataset.clinic;
            document.getElementById('previewPatient').textContent = selected.dataset.patient;
            document.getElementById('previewType').textContent = selected.dataset.type;
            document.getElementById('caseOrderPreview').classList.remove('hidden');
        } else {
            document.getElementById('caseOrderPreview').classList.add('hidden');
        }
    });
}

// Set default datetime to 1 hour from now
const now = new Date();
now.setHours(now.getHours() + 1);
const year = now.getFullYear();
const month = String(now.getMonth() + 1).padStart(2, '0');
const day = String(now.getDate()).padStart(2, '0');
const hours = String(now.getHours()).padStart(2, '0');
const minutes = String(now.getMinutes()).padStart(2, '0');
const datetimeInput = document.querySelector('input[name="schedule_datetime"]');
if (datetimeInput) {
    datetimeInput.value = `${year}-${month}-${day}T${hours}:${minutes}`;
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ᴄᴛOS\Desktop\CAPSTONE\denture-lab-system\resources\views/admin/appointments/create.blade.php ENDPATH**/ ?>