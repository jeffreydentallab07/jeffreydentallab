<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title><?php echo e(ucfirst(str_replace('-', ' ', $reportType))); ?> Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #333;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #1e40af;
            padding-bottom: 15px;
        }

        .header h1 {
            color: #1e40af;
            margin: 0;
            font-size: 24px;
        }

        .header p {
            color: #666;
            margin: 5px 0;
        }

        .info-box {
            background: #f3f4f6;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th {
            background: #1e40af;
            color: white;
            padding: 10px;
            text-align: left;
            font-size: 11px;
            text-transform: uppercase;
        }

        td {
            padding: 8px;
            border-bottom: 1px solid #e5e7eb;
        }

        tr:nth-child(even) {
            background: #f9fafb;
        }

        .summary-box {
            background: #eff6ff;
            padding: 15px;
            margin-bottom: 15px;
            border-left: 4px solid #1e40af;
        }

        .summary-box h3 {
            margin: 0 0 10px 0;
            color: #1e40af;
        }

        .stat-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
        }

        .stat-label {
            color: #666;
        }

        .stat-value {
            font-weight: bold;
            color: #1e40af;
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            font-size: 10px;
            color: #999;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }

        .page-break {
            page-break-after: always;
        }
    </style>
</head>

<body>
    <!-- Header -->
    <div class="header">
        <h1><?php echo e(ucfirst(str_replace('-', ' ', $reportType))); ?> Report</h1>
        <p>Jeffrey Dental Lab Management System</p>
        <p>Report Period: <?php echo e(\Carbon\Carbon::parse($dateFrom)->format('M d, Y')); ?> - <?php echo e(\Carbon\Carbon::parse($dateTo)->format('M d, Y')); ?></p>
        <p>Generated: <?php echo e($generatedAt); ?></p>
    </div>

    <!-- Report Content -->
    <?php if($reportType === 'overview'): ?>
    <div class="summary-box">
        <h3>Case Orders Summary</h3>
        <div class="stat-row">
            <span class="stat-label">Total Cases:</span>
            <span class="stat-value"><?php echo e($data['total_case_orders']); ?></span>
        </div>
        <div class="stat-row">
            <span class="stat-label">Completed:</span>
            <span class="stat-value"><?php echo e($data['completed_cases']); ?></span>
        </div>
        <div class="stat-row">
            <span class="stat-label">Pending:</span>
            <span class="stat-value"><?php echo e($data['pending_cases']); ?></span>
        </div>
    </div>

    <div class="summary-box">
        <h3>Revenue Summary</h3>
        <div class="stat-row">
            <span class="stat-label">Total Revenue:</span>
            <span class="stat-value">₱<?php echo e(number_format($data['total_revenue'], 2)); ?></span>
        </div>
        <div class="stat-row">
            <span class="stat-label">Pending Revenue:</span>
            <span class="stat-value">₱<?php echo e(number_format($data['pending_revenue'], 2)); ?></span>
        </div>
    </div>

    <div class="summary-box">
        <h3>Operational Summary</h3>
        <div class="stat-row">
            <span class="stat-label">Total Appointments:</span>
            <span class="stat-value"><?php echo e($data['total_appointments']); ?></span>
        </div>
        <div class="stat-row">
            <span class="stat-label">Total Deliveries:</span>
            <span class="stat-value"><?php echo e($data['total_deliveries']); ?></span>
        </div>
        <div class="stat-row">
            <span class="stat-label">Total Clinics:</span>
            <span class="stat-value"><?php echo e($data['total_clinics']); ?></span>
        </div>
    </div>

    <?php elseif($reportType === 'case-orders'): ?>
    <div class="summary-box">
        <h3>Case Orders Summary</h3>
        <div class="stat-row">
            <span class="stat-label">Total Cases in Period:</span>
            <span class="stat-value"><?php echo e($data['total_cases']); ?></span>
        </div>
    </div>

    <h3>Case Orders Details</h3>
    <table>
        <thead>
            <tr>
                <th>Case No.</th>
                <th>Clinic</th>
                <th>Patient</th>
                <th>Case Type</th>
                <th>Status</th>
                <th>Created</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data['case_orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>CASE-<?php echo e(str_pad($case->co_id, 5, '0', STR_PAD_LEFT)); ?></td>
                <td><?php echo e($case->clinic->clinic_name); ?></td>
                <td><?php echo e($case->patient->name ?? 'N/A'); ?></td>
                <td><?php echo e($case->case_type); ?></td>
                <td><?php echo e(ucfirst(str_replace('-', ' ', $case->status))); ?></td>
                <td><?php echo e($case->created_at->format('M d, Y')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php elseif($reportType === 'revenue'): ?>
    <div class="summary-box">
        <h3>Revenue Summary</h3>
        <div class="stat-row">
            <span class="stat-label">Total Revenue (Paid):</span>
            <span class="stat-value">₱<?php echo e(number_format($data['total_revenue'], 2)); ?></span>
        </div>
        <div class="stat-row">
            <span class="stat-label">Pending Payment:</span>
            <span class="stat-value">₱<?php echo e(number_format($data['pending_revenue'], 2)); ?></span>
        </div>
        <div class="stat-row">
            <span class="stat-label">Partial Payment:</span>
            <span class="stat-value">₱<?php echo e(number_format($data['partial_revenue'], 2)); ?></span>
        </div>
    </div>

    <h3>Billing Records</h3>
    <table>
        <thead>
            <tr>
                <th>Billing ID</th>
                <th>Clinic</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data['billings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $billing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>BILL-<?php echo e(str_pad($billing->id, 5, '0', STR_PAD_LEFT)); ?></td>
                <td><?php echo e($billing->appointment->caseOrder->clinic->clinic_name); ?></td>
                <td>₱<?php echo e(number_format($billing->total_amount, 2)); ?></td>
                <td><?php echo e(ucfirst($billing->payment_status)); ?></td>
                <td><?php echo e($billing->created_at->format('M d, Y')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php elseif($reportType === 'materials'): ?>
    <div class="summary-box">
        <h3>Materials Summary</h3>
        <div class="stat-row">
            <span class="stat-label">Total Material Cost:</span>
            <span class="stat-value">₱<?php echo e(number_format($data['total_material_cost'], 2)); ?></span>
        </div>
        <div class="stat-row">
            <span class="stat-label">Low/Out of Stock Materials:</span>
            <span class="stat-value"><?php echo e($data['low_stock_materials']->count()); ?></span>
        </div>
    </div>

    <h3>Material Usage</h3>
    <table>
        <thead>
            <tr>
                <th>Material Name</th>
                <th>Total Used</th>
                <th>Unit</th>
                <th>Total Cost</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data['material_usages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($usage->material_name); ?></td>
                <td><?php echo e($usage->total_used); ?></td>
                <td><?php echo e($usage->unit); ?></td>
                <td>₱<?php echo e(number_format($usage->total_cost, 2)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php elseif($reportType === 'clinic-performance'): ?>
    <h3>Clinic Performance Rankings</h3>
    <table>
        <thead>
            <tr>
                <th>Rank</th>
                <th>Clinic Name</th>
                <th>Total Orders</th>
                <th>Completed</th>
                <th>Completion Rate</th>
                <th>Revenue</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data['clinic_stats']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($clinic->clinic_name); ?></td>
                <td><?php echo e($clinic->total_orders); ?></td>
                <td><?php echo e($clinic->completed_orders); ?></td>
                <td><?php echo e($clinic->total_orders > 0 ? number_format(($clinic->completed_orders / $clinic->total_orders *
                    100), 1) : 0); ?>%</td>
                <td>₱<?php echo e(number_format($clinic->total_revenue, 2)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php elseif($reportType === 'technician-performance'): ?>
    <h3>Technician Performance Rankings</h3>
    <table>
        <thead>
            <tr>
                <th>Rank</th>
                <th>Technician Name</th>
                <th>Total Appointments</th>
                <th>Completed</th>
                <th>Completion Rate</th>
                <th>Materials Used</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data['technician_stats']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $technician): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($technician->name); ?></td>
                <td><?php echo e($technician->total_appointments); ?></td>
                <td><?php echo e($technician->completed_appointments); ?></td>
                <td><?php echo e($technician->total_appointments > 0 ? number_format(($technician->completed_appointments /
                    $technician->total_appointments * 100), 1) : 0); ?>%</td>
                <td><?php echo e($technician->materials_used); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php elseif($reportType === 'delivery-performance'): ?>
    <h3>Rider Performance Rankings</h3>
    <table>
        <thead>
            <tr>
                <th>Rank</th>
                <th>Rider Name</th>
                <th>Total Deliveries</th>
                <th>Completed</th>
                <th>Total Pickups</th>
                <th>Completed Pickups</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data['rider_stats']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($rider->name); ?></td>
                <td><?php echo e($rider->total_deliveries); ?></td>
                <td><?php echo e($rider->completed_deliveries); ?></td>
                <td><?php echo e($rider->total_pickups); ?></td>
                <td><?php echo e($rider->completed_pickups); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>

    <!-- Footer -->
    <div class="footer">
        <p>Jeffrey Dental Lab - Confidential Report - Page 1</p>
    </div>
</body>

</html><?php /**PATH C:\Users\ᴄᴛOS\Desktop\CAPSTONE\denture-lab-system\resources\views/admin/reports/pdf.blade.php ENDPATH**/ ?>