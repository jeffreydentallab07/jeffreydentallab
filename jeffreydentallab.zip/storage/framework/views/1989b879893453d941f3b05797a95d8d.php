<?php $__env->startSection('page-title', 'Reports & Analytics'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 space-y-6 bg-gray-300 min-h-screen">

    <!-- Header -->
    <div class="flex justify-between items-center">
        <div>
            <h1 class="text-2xl font-bold text-gray-800">Reports & Analytics</h1>
            <p class="text-gray-600">Generate and export comprehensive business reports</p>
        </div>
        <button onclick="exportPDF()"
            class="bg-red-600 text-white px-5 py-2 rounded font-semibold hover:bg-red-700 transition flex items-center gap-2">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z">
                </path>
            </svg>
            Export PDF
        </button>
    </div>

    <!-- Filter Section -->
    <div class="bg-white rounded-lg shadow p-6">
        <form method="GET" action="<?php echo e(route('admin.reports.index')); ?>" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Report Type</label>
                <select name="type"
                    class="w-full border-2 border-gray-300 rounded-lg p-2 focus:border-blue-500 focus:outline-none">
                    <option value="overview" <?php echo e($reportType==='overview' ? 'selected' : ''); ?>>Overview</option>
                    <option value="case-orders" <?php echo e($reportType==='case-orders' ? 'selected' : ''); ?>>Case Orders</option>
                    <option value="revenue" <?php echo e($reportType==='revenue' ? 'selected' : ''); ?>>Revenue</option>
                    <option value="materials" <?php echo e($reportType==='materials' ? 'selected' : ''); ?>>Materials</option>
                    <option value="clinic-performance" <?php echo e($reportType==='clinic-performance' ? 'selected' : ''); ?>>Clinic
                        Performance</option>
                    <option value="technician-performance" <?php echo e($reportType==='technician-performance' ? 'selected' : ''); ?>>Technician Performance</option>
                    <option value="delivery-performance" <?php echo e($reportType==='delivery-performance' ? 'selected' : ''); ?>>
                        Delivery Performance</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Date From</label>
                <input type="date" name="date_from" value="<?php echo e($dateFrom); ?>"
                    class="w-full border-2 border-gray-300 rounded-lg p-2 focus:border-blue-500 focus:outline-none">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Date To</label>
                <input type="date" name="date_to" value="<?php echo e($dateTo); ?>"
                    class="w-full border-2 border-gray-300 rounded-lg p-2 focus:border-blue-500 focus:outline-none">
            </div>
            <div class="flex items-end">
                <button type="submit"
                    class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition font-semibold">
                    Generate Report
                </button>
            </div>
        </form>
    </div>

    <!-- Report Content -->
    <div id="reportContent">
        <?php if($reportType === 'overview'): ?>
        <?php echo $__env->make('admin.reports.partials.overview', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif($reportType === 'case-orders'): ?>
        <?php echo $__env->make('admin.reports.partials.case-orders', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif($reportType === 'revenue'): ?>
        <?php echo $__env->make('admin.reports.partials.revenue', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif($reportType === 'materials'): ?>
        <?php echo $__env->make('admin.reports.partials.materials', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif($reportType === 'clinic-performance'): ?>
        <?php echo $__env->make('admin.reports.partials.clinic-performance', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif($reportType === 'technician-performance'): ?>
        <?php echo $__env->make('admin.reports.partials.technician-performance', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif($reportType === 'delivery-performance'): ?>
        <?php echo $__env->make('admin.reports.partials.delivery-performance', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </div>
</div>

<script>
    function exportPDF() {
    const params = new URLSearchParams(window.location.search);
    window.location.href = '<?php echo e(route("admin.reports.exportPdf")); ?>?' + params.toString();
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ᴄᴛOS\Desktop\CAPSTONE\denture-lab-system\resources\views/admin/reports/index.blade.php ENDPATH**/ ?>