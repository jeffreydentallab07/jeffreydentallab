<?php $__env->startSection('content'); ?>
<div class="p-6 bg-gray-100 min-h-screen">
    <div class="max-w-6xl mx-auto">

        <a href="<?php echo e(route('admin.clinics.index')); ?>" class="text-blue-600 hover:underline mb-4 inline-block">
            ← Back to Clinics
        </a>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

            <!-- Main Content -->
            <div class="lg:col-span-2 space-y-6">

                <!-- Clinic Info Card -->
                <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                    <div class="bg-gradient-to-r from-blue-900 to-blue-700 p-6 text-white">
                        <div class="flex items-center gap-6">
                            <img src="<?php echo e($clinic->profile_photo ? asset('storage/' . $clinic->profile_photo) : asset('images/default-clinic.png')); ?>"
                                alt="<?php echo e($clinic->clinic_name); ?>"
                                class="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg">
                            <div>
                                <h1 class="text-3xl font-bold"><?php echo e($clinic->clinic_name); ?></h1>
                                <p class="text-blue-100 mt-1"><?php echo e($clinic->email); ?></p>
                                <p class="text-blue-100"><?php echo e($clinic->contact_number ?? 'No contact'); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="p-6">
                        <h2 class="text-xl font-bold text-gray-800 mb-4">Clinic Information</h2>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <p class="text-sm text-gray-500">Clinic Name</p>
                                <p class="text-lg font-semibold text-gray-800"><?php echo e($clinic->clinic_name); ?></p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Email</p>
                                <p class="text-lg font-semibold text-gray-800"><?php echo e($clinic->email); ?></p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Contact Number</p>
                                <p class="text-lg font-semibold text-gray-800"><?php echo e($clinic->contact_number ?? 'N/A'); ?>

                                </p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Member Since</p>
                                <p class="text-lg font-semibold text-gray-800"><?php echo e($clinic->created_at->format('M d, Y')); ?></p>
                            </div>
                        </div>

                        <?php if($clinic->address): ?>
                        <div class="mt-4 pt-4 border-t">
                            <p class="text-sm text-gray-500">Address</p>
                            <p class="text-gray-700 mt-1"><?php echo e($clinic->address); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recent Case Orders -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">Recent Case Orders</h2>

                    <div class="space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $recentCaseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caseOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="border-l-4 border-blue-500 pl-4 py-3 bg-gray-50 rounded">
                            <div class="flex justify-between items-start">
                                <div>
                                    <p class="font-semibold text-gray-800">CASE-<?php echo e(str_pad($caseOrder->co_id, 5, '0',
                                        STR_PAD_LEFT)); ?></p>
                                    <p class="text-sm text-gray-600">Patient: <?php echo e($caseOrder->patient->name ?? 'N/A'); ?>

                                    </p>
                                    <p class="text-sm text-gray-600">Dentist: Dr. <?php echo e($caseOrder->dentist->name ?? 'N/A'); ?></p>
                                    <p class="text-xs text-gray-500 mt-1"><?php echo e($caseOrder->case_type); ?></p>
                                    <p class="text-xs text-gray-400"><?php echo e($caseOrder->created_at->format('M d, Y')); ?></p>
                                </div>
                                <span
                                    class="px-2 py-1 text-xs rounded-full
                                    <?php echo e($caseOrder->status === 'completed' ? 'bg-green-100 text-green-800' : 
                                       ($caseOrder->status === 'in-progress' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800')); ?>">
                                    <?php echo e(ucfirst($caseOrder->status)); ?>

                                </span>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-gray-500 text-center py-4">No case orders yet.</p>
                        <?php endif; ?>
                    </div>

                    <?php if($clinic->case_orders_count > 10): ?>
                    <div class="mt-4 text-center">
                        <a href="<?php echo e(route('admin.case-orders.index', ['clinic_id' => $clinic->clinic_id])); ?>"
                            class="text-blue-600 hover:underline text-sm">
                            View All <?php echo e($clinic->case_orders_count); ?> Case Orders →
                        </a>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Dentists List -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">Dentists (<?php echo e($clinic->dentists_count); ?>)</h2>

                    <div class="space-y-2">
                        <?php $__empty_1 = true; $__currentLoopData = $clinic->dentists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dentist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-center gap-3 p-3 bg-gray-50 rounded">
                            <img src="<?php echo e($dentist->photo ? asset('storage/' . $dentist->photo) : asset('images/default-avatar.png')); ?>"
                                alt="<?php echo e($dentist->name); ?>" class="w-10 h-10 rounded-full object-cover border">
                            <div>
                                <p class="font-semibold text-gray-800">Dr. <?php echo e($dentist->name); ?></p>
                                <p class="text-sm text-gray-600"><?php echo e($dentist->email ?? 'No email'); ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-gray-500 text-center py-4">No dentists registered.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Patients List -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">Patients (<?php echo e($clinic->patients_count); ?>)</h2>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <?php $__empty_1 = true; $__currentLoopData = $clinic->patients->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="p-3 bg-gray-50 rounded border-l-4 border-green-500">
                            <p class="font-semibold text-gray-800"><?php echo e($patient->name); ?></p>
                            <p class="text-sm text-gray-600"><?php echo e($patient->contact_number ?? 'No contact'); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-gray-500 text-center py-4 col-span-2">No patients registered.</p>
                        <?php endif; ?>
                    </div>

                    <?php if($clinic->patients_count > 10): ?>
                    <div class="mt-4 text-center">
                        <p class="text-gray-500 text-sm">Showing 10 of <?php echo e($clinic->patients_count); ?> patients</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Sidebar Stats -->
            <div class="space-y-6">

                <!-- Statistics Card -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-4">Statistics</h3>

                    <div class="space-y-4">
                        <div class="bg-blue-50 p-4 rounded-lg">
                            <p class="text-sm text-gray-600">Total Case Orders</p>
                            <p class="text-3xl font-bold text-blue-600"><?php echo e($totalCaseOrders); ?></p>
                        </div>

                        <div class="bg-green-50 p-4 rounded-lg">
                            <p class="text-sm text-gray-600">Completed</p>
                            <p class="text-3xl font-bold text-green-600"><?php echo e($completedCaseOrders); ?></p>
                        </div>

                        <div class="bg-yellow-50 p-4 rounded-lg">
                            <p class="text-sm text-gray-600">Pending/In Progress</p>
                            <p class="text-3xl font-bold text-yellow-600"><?php echo e($pendingCaseOrders); ?></p>
                        </div>

                        <div class="bg-purple-50 p-4 rounded-lg">
                            <p class="text-sm text-gray-600">Total Dentists</p>
                            <p class="text-3xl font-bold text-purple-600"><?php echo e($clinic->dentists_count); ?></p>
                        </div>

                        <div class="bg-pink-50 p-4 rounded-lg">
                            <p class="text-sm text-gray-600">Total Patients</p>
                            <p class="text-3xl font-bold text-pink-600"><?php echo e($clinic->patients_count); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Activity Timeline -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-4">Activity</h3>

                    <div class="space-y-3">
                        <div class="flex gap-3">
                            <div class="w-2 h-2 bg-green-500 rounded-full mt-1.5"></div>
                            <div>
                                <p class="text-sm font-medium text-gray-800">Registered</p>
                                <p class="text-xs text-gray-500"><?php echo e($clinic->created_at->format('M d, Y')); ?></p>
                            </div>
                        </div>

                        <?php if($clinic->updated_at != $clinic->created_at): ?>
                        <div class="flex gap-3">
                            <div class="w-2 h-2 bg-blue-500 rounded-full mt-1.5"></div>
                            <div>
                                <p class="text-sm font-medium text-gray-800">Last Updated</p>
                                <p class="text-xs text-gray-500"><?php echo e($clinic->updated_at->format('M d, Y')); ?></p>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($recentCaseOrders->isNotEmpty()): ?>
                        <div class="flex gap-3">
                            <div class="w-2 h-2 bg-purple-500 rounded-full mt-1.5"></div>
                            <div>
                                <p class="text-sm font-medium text-gray-800">Latest Case Order</p>
                                <p class="text-xs text-gray-500"><?php echo e($recentCaseOrders->first()->created_at->format('M d,
                                    Y')); ?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ᴄᴛOS\Desktop\CAPSTONE\denture-lab-system\resources\views/admin/clinics/show.blade.php ENDPATH**/ ?>