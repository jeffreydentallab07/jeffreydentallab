<?php $__env->startSection('page-title', 'Create Delivery'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 bg-gray-100 min-h-screen">
    <div class="max-w-4xl mx-auto">

        <a href="<?php echo e(route('admin.delivery.index')); ?>" class="text-blue-600 hover:underline mb-4 inline-block">
            ← Back to Deliveries
        </a>

        <div class="bg-white rounded-lg shadow-lg p-6">
            <h1 class="text-2xl font-bold text-gray-800 mb-6">Create New Delivery</h1>

            <?php if($errors->any()): ?>
            <div class="mb-4 p-4 bg-red-100 border border-red-300 text-red-700 rounded">
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <form action="<?php echo e(route('admin.delivery.store')); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>

                <!-- Appointment Selection -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Select Completed Case <span class="text-red-500">*</span>
                    </label>

                    <?php if($appointment): ?>
                    <!-- Pre-selected appointment -->
                    <div class="border-2 border-green-500 rounded-lg p-4 bg-green-50">
                        <div class="flex items-center justify-between mb-3">
                            <div>
                                <p class="font-semibold text-gray-800">APT-<?php echo e(str_pad($appointment->appointment_id, 5,
                                    '0', STR_PAD_LEFT)); ?></p>
                                <p class="text-sm text-gray-600">CASE-<?php echo e(str_pad($appointment->case_order_id, 5, '0',
                                    STR_PAD_LEFT)); ?></p>
                            </div>
                            <span class="px-3 py-1 bg-green-600 text-white rounded-full text-xs">Ready for
                                Delivery</span>
                        </div>
                        <div class="grid grid-cols-2 gap-3 text-sm">
                            <div>
                                <p class="text-gray-500">Clinic:</p>
                                <p class="font-medium text-gray-800"><?php echo e($appointment->caseOrder->clinic->clinic_name); ?>

                                </p>
                            </div>
                            <div>
                                <p class="text-gray-500">Address:</p>
                                <p class="font-medium text-gray-800"><?php echo e($appointment->caseOrder->clinic->address); ?></p>
                            </div>
                            <div>
                                <p class="text-gray-500">Contact:</p>
                                <p class="font-medium text-gray-800"><?php echo e($appointment->caseOrder->clinic->contact_number); ?></p>
                            </div>
                            <div>
                                <p class="text-gray-500">Total Amount:</p>
                                <p class="font-medium text-green-600">₱<?php echo e(number_format($appointment->billing->total_amount, 2)); ?></p>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="appointment_id" value="<?php echo e($appointment->appointment_id); ?>">
                    <?php else: ?>
                    <!-- Dropdown selection -->
                    <select name="appointment_id" id="appointmentSelect" required
                        class="w-full border-2 border-gray-300 rounded-lg p-3 focus:border-blue-500 focus:outline-none"
                        onchange="updateAppointmentDetails()">
                        <option value="">-- Select Completed Case --</option>
                        <?php $__currentLoopData = $readyAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($apt->appointment_id); ?>"
                            data-clinic="<?php echo e($apt->caseOrder->clinic->clinic_name); ?>"
                            data-address="<?php echo e($apt->caseOrder->clinic->address); ?>"
                            data-contact="<?php echo e($apt->caseOrder->clinic->contact_number); ?>"
                            data-amount="<?php echo e($apt->billing->total_amount); ?>">
                            APT-<?php echo e(str_pad($apt->appointment_id, 5, '0', STR_PAD_LEFT)); ?> - <?php echo e($apt->caseOrder->clinic->clinic_name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <!-- Appointment Preview -->
                    <div id="appointmentPreview" class="hidden mt-3 p-4 bg-gray-50 rounded-lg border">
                        <div class="grid grid-cols-2 gap-3 text-sm">
                            <div>
                                <p class="text-gray-500">Clinic:</p>
                                <p class="font-medium text-gray-800" id="previewClinic"></p>
                            </div>
                            <div>
                                <p class="text-gray-500">Address:</p>
                                <p class="font-medium text-gray-800" id="previewAddress"></p>
                            </div>
                            <div>
                                <p class="text-gray-500">Contact:</p>
                                <p class="font-medium text-gray-800" id="previewContact"></p>
                            </div>
                            <div>
                                <p class="text-gray-500">Total Amount:</p>
                                <p class="font-medium text-green-600" id="previewAmount"></p>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Rider Selection -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Assign Rider <span class="text-red-500">*</span>
                    </label>
                    <select name="rider_id" required
                        class="w-full border-2 border-gray-300 rounded-lg p-3 focus:border-blue-500 focus:outline-none">
                        <option value="">-- Select Rider --</option>
                        <?php $__currentLoopData = $riders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($rider->id); ?>">
                            <?php echo e($rider->name); ?> - <?php echo e($rider->contact_number ?? $rider->email); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <p class="text-xs text-gray-500 mt-1">The rider will be notified immediately upon delivery creation.
                    </p>
                </div>

                <!-- Delivery Date -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Scheduled Delivery Date (Optional)
                    </label>
                    <input type="date" name="delivery_date" min="<?php echo e(date('Y-m-d')); ?>"
                        value="<?php echo e(date('Y-m-d', strtotime('+1 day'))); ?>"
                        class="w-full border-2 border-gray-300 rounded-lg p-3 focus:border-blue-500 focus:outline-none">
                    <p class="text-xs text-gray-500 mt-1">If not specified, delivery will be scheduled for tomorrow.</p>
                </div>

                <!-- Notes -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Delivery Notes (Optional)
                    </label>
                    <textarea name="notes" rows="4"
                        class="w-full border-2 border-gray-300 rounded-lg p-3 focus:border-blue-500 focus:outline-none"
                        placeholder="Special instructions for delivery..."></textarea>
                </div>

                <!-- Info Box -->
                

                <!-- Action Buttons -->
                <div class="flex justify-end gap-3 pt-4 border-t">
                    <a href="<?php echo e(route('admin.delivery.index')); ?>"
                        class="px-6 py-3 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition">
                        Cancel
                    </a>
                    <button type="submit"
                        class="px-6 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition font-semibold">
                        Create Delivery
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function updateAppointmentDetails() {
    const select = document.getElementById('appointmentSelect');
    const option = select.options[select.selectedIndex];
    
    if (select.value) {
        document.getElementById('previewClinic').textContent = option.dataset.clinic;
        document.getElementById('previewAddress').textContent = option.dataset.address;
        document.getElementById('previewContact').textContent = option.dataset.contact;
        document.getElementById('previewAmount').textContent = '₱' + parseFloat(option.dataset.amount).toLocaleString('en-US', {minimumFractionDigits: 2});
        document.getElementById('appointmentPreview').classList.remove('hidden');
    } else {
        document.getElementById('appointmentPreview').classList.add('hidden');
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ᴄᴛOS\Desktop\CAPSTONE\denture-lab-system\resources\views/admin/delivery/create.blade.php ENDPATH**/ ?>