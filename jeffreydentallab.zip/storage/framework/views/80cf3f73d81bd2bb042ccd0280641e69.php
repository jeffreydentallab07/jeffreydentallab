<?php $__env->startSection('title', 'Work History'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 bg-gray-100 min-h-screen">
    <div class="max-w-7xl mx-auto">

        <div class="mb-6">
            <h1 class="text-2xl font-bold text-gray-800">Work History</h1>
            <p class="text-gray-600">All your completed work records</p>
        </div>

        <!-- Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-gray-500 text-sm font-medium">Total Completed</h3>
                <p class="text-3xl font-bold text-green-600 mt-2"><?php echo e($completedAppointments->total()); ?></p>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-gray-500 text-sm font-medium">This Month</h3>
                <p class="text-3xl font-bold text-blue-600 mt-2">
                    <?php echo e($completedAppointments->filter(function($apt) {
                    return $apt->updated_at->isCurrentMonth();
                    })->count()); ?>

                </p>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-gray-500 text-sm font-medium">This Week</h3>
                <p class="text-3xl font-bold text-purple-600 mt-2">
                    <?php echo e($completedAppointments->filter(function($apt) {
                    return $apt->updated_at->isCurrentWeek();
                    })->count()); ?>

                </p>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-gray-500 text-sm font-medium">Materials Used</h3>
                <p class="text-3xl font-bold text-orange-600 mt-2">
                    <?php echo e($completedAppointments->sum(function($apt) {
                    return $apt->materialUsages->count();
                    })); ?>

                </p>
            </div>
        </div>

        <!-- Completed Appointments List -->
        <div class="bg-white rounded-lg shadow">
            <div class="p-6 border-b">
                <h2 class="text-xl font-bold text-gray-800">Completed Work</h2>
            </div>

            <?php if($completedAppointments->count() > 0): ?>
            <div class="divide-y divide-gray-200">
                <?php $__currentLoopData = $completedAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-6 hover:bg-gray-50 transition">
                    <div class="flex items-start justify-between">
                        <div class="flex-1">
                            <!-- Header -->
                            <div class="flex items-center gap-3 mb-3">
                                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                                    <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                </div>
                                <div>
                                    <h3 class="text-lg font-bold text-gray-800">
                                        APT-<?php echo e(str_pad($appointment->appointment_id, 5, '0', STR_PAD_LEFT)); ?>

                                    </h3>
                                    <p class="text-sm text-gray-600">
                                        CASE-<?php echo e(str_pad($appointment->case_order_id, 5, '0', STR_PAD_LEFT)); ?>

                                    </p>
                                </div>
                            </div>

                            <!-- Details Grid -->
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
                                <div>
                                    <p class="text-xs text-gray-500">Clinic</p>
                                    <p class="text-sm font-medium text-gray-800"><?php echo e($appointment->caseOrder->clinic->clinic_name); ?></p>
                                </div>
                                <div>
                                    <p class="text-xs text-gray-500">Case Type</p>
                                    <p class="text-sm font-medium text-gray-800"><?php echo e($appointment->caseOrder->case_type); ?></p>
                                </div>
                                <div>
                                    <p class="text-xs text-gray-500">Patient</p>
                                    <p class="text-sm font-medium text-gray-800"><?php echo e($appointment->caseOrder->patient->name ?? 'N/A'); ?></p>
                                </div>
                            </div>

                            <!-- Materials Used -->
                            <?php if($appointment->materialUsages->count() > 0): ?>
                            <div class="mb-3">
                                <p class="text-xs text-gray-500 mb-2">Materials Used:</p>
                                <div class="flex flex-wrap gap-2">
                                    <?php $__currentLoopData = $appointment->materialUsages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span
                                        class="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">
                                        <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                            <path
                                                d="M10 2a1 1 0 011 1v1.323l3.954 1.582 1.599-.8a1 1 0 01.894 1.79l-1.233.616 1.738 5.42a1 1 0 01-.285 1.05A3.989 3.989 0 0115 15a3.989 3.989 0 01-2.667-1.019 1 1 0 01-.285-1.05l1.738-5.42-1.233-.617a1 1 0 01.894-1.788l1.599.799L11 4.323V3a1 1 0 011-1zm-5 8.274l-.818 2.552c-.25.78.074 1.623.736 2.115A3.989 3.989 0 007 16a3.989 3.989 0 002.082-1.06c.662-.492.986-1.335.736-2.114L9 10.274V6a1 1 0 00-2 0v4.274z">
                                            </path>
                                        </svg>
                                        <?php echo e($usage->material->material_name); ?> (<?php echo e($usage->quantity_used); ?> <?php echo e($usage->material->unit); ?>)
                                    </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <?php endif; ?>

                            <!-- Footer Info -->
                            <div class="flex items-center gap-4 text-xs text-gray-500">
                                <div class="flex items-center gap-1">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z">
                                        </path>
                                    </svg>
                                    <span>Scheduled: <?php echo e($appointment->schedule_datetime->format('M d, Y h:i A')); ?></span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span>Completed: <?php echo e($appointment->updated_at->format('M d, Y h:i A')); ?></span>
                                </div>
                            </div>
                        </div>

                        <!-- Action Button -->
                        <div class="ml-4">
                            <a href="<?php echo e(route('technician.appointments.show', $appointment->appointment_id)); ?>"
                                class="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition text-sm">
                                View Details
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M9 5l7 7-7 7"></path>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Pagination -->
            <div class="p-6 border-t">
                <?php echo e($completedAppointments->links()); ?>

            </div>
            <?php else: ?>
            <div class="p-12 text-center">
                <svg class="w-16 h-16 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z">
                    </path>
                </svg>
                <p class="text-gray-500">No completed work yet</p>
                <p class="text-sm text-gray-400 mt-2">Your completed appointments will appear here</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.technician', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ᴄᴛOS\Desktop\CAPSTONE\denture-lab-system\resources\views/technician/work-history.blade.php ENDPATH**/ ?>